<?php $__env->startSection('title', 'Laravel - SI penjualan online'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron">

            <?php
                $alamat = ['Tegal', 'Pemalang', 'Pekalongan','Brebes',"SEMUA"];
            ?>


            <?php if($msg = Session::get('msg')): ?>
                <div class="alert alert-success">
                    <span><?php echo e($msg); ?></span>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>   
                </div>
            <?php endif; ?> 

            <h1 class="display-6">Data Pelanggan</h1>
            <hr class="my-2">     

            <a href="<?php echo e(route('pelanggan.create')); ?>" class="btn btn-primary mb-1 my-3">Tambah Pelanggan</a>
            <form action="<?php echo e(route('pelanggan.index')); ?>" class="row mb-4">
                    <div class="col-md-8">
                        <select name="alamat" class="form-control">
                            <option value="" disabled selected>Pilih alamat</option>
                            <?php $__currentLoopData = $alamat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($almt=="SEMUA" ? "" : $almt); ?>" ><?php echo e($almt); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                    <input type="submit" class="btn btn-success float-right mb-4" value="Cari">

            <table class="table">
                <thead class="thead-dark">
                    <tr>
                
                    <th scope="col">Id</th>
                    <th scope="col">Nama Karyawan</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">No Hp</th>
                    <th scope="col">Action</th>
                    
                    <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dataPelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($plg['id']); ?></td>
                        <td><?php echo e($plg['nama']); ?></td>
                        <td><?php echo e($plg['alamat']); ?></td>
                        <td><?php echo e($plg['no_hp']); ?></td>

                        <td>
                            <form action="<?php echo e(route('pelanggan.destroy',$plg['id'])); ?>" method="POST">
                            <a href="<?php echo e(route('pelanggan.show',$plg['id'])); ?>" class="badge badge-primary">Detail</a>
                            <a href="<?php echo e(route('pelanggan.edit',$plg['id'])); ?>" class="badge badge-primary">Edit</a>
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="badge badge-danger" onclick="return confirm('Yakin ingin menghapus data?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        function action(){
            var alamat = document.getElementById('alamat').value;
            window.location.href = "<?php echo e(url('pelanggan')); ?>/"+alamat
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gabungan\resources\views/Data_Pelanggan/data-pelanggan.blade.php ENDPATH**/ ?>